//*****************************************************************************
//
// freertos_demo.c - Simple FreeRTOS example.
//
// Copyright (c) 2012-2017 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 2.1.4.178 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************

#include "FreeRTOSConfig.h"
#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "led_task.h"
#include "switch_task.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

#include "time.h"
#include "timers.h"

/*
Uncomment for accessing the question number
*/

//#define Q1
//#define Q2
//#define Q3


unsigned int idx = 0, jdx = 1;
unsigned int seqIterations = 47;
unsigned int reqIterations = 10500;         //for 10 ticks
volatile unsigned int fib = 0, fib0 = 0, fib1 = 1;


/*
    Fibonacci Test
    (referred from Sam Siewerts code)
*/

#define FIB_TEST(seqCnt, iterCnt)      \
   for(idx=0; idx < iterCnt; idx++)    \
   {                                   \
      fib = fib0 + fib1;               \
      while(jdx < seqCnt)              \
      {                                \
         fib0 = fib1;                  \
         fib1 = fib;                   \
         fib = fib0 + fib1;            \
         jdx++;                        \
      }                                \
   }                                   \



//*****************************************************************************
//
// The mutex that protects concurrent access of UART from multiple tasks.
//
//*****************************************************************************
xSemaphoreHandle g_pUARTSemaphore;

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}

#endif

//*****************************************************************************
//
// This hook is called by FreeRTOS when an stack overflow error is detected.
//
//*****************************************************************************
void
vApplicationStackOverflowHook(xTaskHandle *pxTask, char *pcTaskName)
{
    //
    // This function can not return, so loop forever.  Interrupts are disabled
    // on entry to this function, so no processor interrupts will interrupt
    // this loop.
    //
    while(1)
    {
    }
}

//*****************************************************************************
//
// Configure the UART and its pins.  This must be called before UARTprintf().
//
//*****************************************************************************
void
ConfigureUART(void)
{
    //
    // Enable the GPIO Peripheral used by the UART.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    //
    // Enable UART0
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    //
    // Configure GPIO Pins for UART mode.
    //
    ROM_GPIOPinConfigure(GPIO_PA0_U0RX);
    ROM_GPIOPinConfigure(GPIO_PA1_U0TX);
    ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    //
    // Use the internal 16MHz oscillator as the UART clock source.
    //
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);

    //
    // Initialize the UART for console I/O.
    //
    UARTStdioConfig(0, 115200, 16000000);
}
/*
Function implemented to have workload generation of 10*num msecs
*/
void delay_Fibo(int num)
{

    TickType_t xTimeStart;
    TickType_t xTimeEnd;
    TickType_t xTimeTaken;
    xTimeStart = xTaskGetTickCount();
    FIB_TEST(seqIterations, num*reqIterations);
    xTimeEnd = xTaskGetTickCount();

    xTimeTaken = xTimeEnd - xTimeStart;
    xTimeTaken = xTimeTaken/portTICK_PERIOD_MS;

    UARTprintf("\n\rTime taken for Fibonacci is %d ms",xTimeTaken);

}

/*
Handles and Definitions
*/
TaskHandle_t xTimer1;
TaskHandle_t xTimer2;

TickType_t Ticks_ISR;
TickType_t Ticks_ISR1;
TickType_t Ticks_ISR2;

SemaphoreHandle_t xSemaphore1;
SemaphoreHandle_t xSemaphore2;

/* The task functions. */
void vTask1( void *pvParameters );
void vTask2( void *pvParameters );
void vTask3( void *pvParameters );
void vTask4( void *pvParameters );
void vTask5( void *pvParameters );
void Timer1_ISR_Handler( TimerHandle_t xTimer1 );
void Timer2_ISR_Handler( TimerHandle_t xTimer2 );


//*****************************************************************************
//
// Initialize FreeRTOS and start the initial set of tasks.
//
//*****************************************************************************
int
main(void)
{
    //
    // Set the clocking to run at 50 MHz from the PLL.
    //
    ROM_SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ |
                       SYSCTL_OSC_MAIN);

    //
    // Initialize the UART and configure it for 115,200, 8-N-1 operation.
    //
    ConfigureUART();

    //
    // Print demo introduction.
    //
    UARTprintf("\n\nWelcome to the EK-TM4C123GXL FreeRTOS Demo!\n");

    //delay_Fibo();

    //
    // Create a mutex to guard the UART.
    //
    g_pUARTSemaphore = xSemaphoreCreateMutex();

#ifdef Q3
    xTimer1 = xTimerCreate("Timer1", pdMS_TO_TICKS(30), pdTRUE, NULL, Timer1_ISR_Handler);
        if( xTimer1 == NULL )
         {
             UARTprintf("\n\rThe timer1 was not created.");
         }
        else
         {
             /* Start the timer.  No block time is specified, and
             even if one was it would be ignored because the RTOS
             scheduler has not yet been started. */
             if( xTimerStart( xTimer1, 0 ) != pdPASS )
             {
                UARTprintf("\n\rThe timer1 could not be set into the Active state.");
             }
         }

    xTimer2 = xTimerCreate("Timer2", pdMS_TO_TICKS(80), pdTRUE, NULL, Timer2_ISR_Handler);
        if( xTimer1 == NULL )
         {
             UARTprintf("\n\rThe timer2 was not created.");
         }
        else
         {
             /* Start the timer.  No block time is specified, and
             even if one was it would be ignored because the RTOS
             scheduler has not yet been started. */
             if( xTimerStart( xTimer2, 0 ) != pdPASS )
             {
                UARTprintf("\n\rThe timer2 could not be set into the Active state.");
             }
         }

    xSemaphore1 = xSemaphoreCreateBinary();
           if( xSemaphore1 == NULL )
               {
                   UARTprintf("\n\rBinary Semaphore 1 not created.");
               }
    xSemaphore2 = xSemaphoreCreateBinary();
          if( xSemaphore2 == NULL )
              {
                  UARTprintf("\n\rBinary Semaphore 2 not created.");
              }

    xTaskCreate( vTask4, "Task 4", 1000, NULL, 2, NULL);
    xTaskCreate( vTask5, "Task 5", 1000, NULL, 1, NULL);

    Ticks_ISR = xTaskGetTickCount();
    //xSemaphoreGive(xSemaphore1);


#endif

#ifdef Q2
    xSemaphore1 = xSemaphoreCreateBinary();
       if( xSemaphore1 == NULL )
           {
               UARTprintf("\n\rBinary Semaphore 1 not created.");
           }
    xSemaphore2 = xSemaphoreCreateBinary();
      if( xSemaphore2 == NULL )
          {
              UARTprintf("\n\rBinary Semaphore 2 not created.");
          }

    xTaskCreate( vTask1, "Task1", 1000, NULL, 1, NULL);
    xTaskCreate( vTask2, "Task 2", 1000, NULL, 1, NULL);  //&xTask2Handle );

    xSemaphoreGive(xSemaphore2);
#endif

#ifdef Q1
    xSemaphore1 = xSemaphoreCreateBinary();
    if( xSemaphore1 == NULL )
        {
            UARTprintf("\n\rBinary Semaphore not created.");
        }

    xTimer1 = xTimerCreate("Timer1", pdMS_TO_TICKS(2500), pdTRUE, NULL, Timer1_ISR_Handler);
    if( xTimer1 == NULL )
     {
         UARTprintf("\n\rThe timer was not created.");
     }
    else
     {
         /* Start the timer.  No block time is specified, and
         even if one was it would be ignored because the RTOS
         scheduler has not yet been started. */
         if( xTimerStart( xTimer1, 0 ) != pdPASS )
         {
            UARTprintf("\n\rThe timer could not be set into the Active state.");
         }
     }

    xTaskCreate( vTask3, "Task3", 1000, NULL, 2, NULL);
#endif

    //
    // Start the scheduler.  This should not return.
    //
    vTaskStartScheduler();

    //
    // In case the scheduler returns for some reason, print an error and loop
    // forever.
    //

    while(1)
    {
    }
}

void vTask1( void *pvParameters )
{
    //UBaseType_t uxPriority;

    //uxPriority = uxTaskPriorityGet( NULL );

    UARTprintf("\n\rTask1 created");

    for(;;)
    {
    xSemaphoreTake(xSemaphore2,portMAX_DELAY);
    delay_Fibo(1);
    UARTprintf("\n\r Now Task 2 should run");
    xSemaphoreGive(xSemaphore1);
    //vTaskPrioritySet(xTask2Handle, (uxPriority+1));
    }
}

void vTask2( void *pvParameters )
{
    //UBaseType_t uxPriority;

    //uxPriority = uxTaskPriorityGet( NULL );

    UARTprintf("\n\rTask2 created");

    for(;;)
    {
    xSemaphoreTake(xSemaphore1,portMAX_DELAY);
    delay_Fibo(4);
    UARTprintf("\n\r Now Task 1 should run");
    xSemaphoreGive(xSemaphore2);
    //vTaskPrioritySet(NULL, (uxPriority-2));
    }
}

void vTask3( void *pvParameters )
{
    UARTprintf("\n\rTask3 created");

    for(;;)
    {
        UARTprintf(" at Time: %d",Ticks_ISR);
        xSemaphoreTake(xSemaphore1, portMAX_DELAY);
    }
}

void vTask4( void *pvParameters )
{
    UARTprintf("\n\rTask4 created");

    for(;;)
    {
    xSemaphoreTake(xSemaphore1,portMAX_DELAY);
    Ticks_ISR = xTaskGetTickCount();
    UARTprintf("\n\rTask 4 runs at Time : %d",Ticks_ISR);
    FIB_TEST(seqIterations, 9500);
    Ticks_ISR = xTaskGetTickCount();
    UARTprintf("\n\rTask 4 stops at Time : %d",Ticks_ISR);
    }
}

void vTask5( void *pvParameters )
{
    UARTprintf("\n\rTask5 created");

    for(;;)
    {
    xSemaphoreTake(xSemaphore2,portMAX_DELAY);
    UARTprintf("\n\rTask 5 runs at Time : %d",xTaskGetTickCount());
    FIB_TEST(seqIterations, 30000);
    UARTprintf("\n\rTask 5 stops at Time : %d",xTaskGetTickCount());
    }
}
#ifdef Q1
void Timer1_ISR_Handler( TimerHandle_t xTimer1 )
{
    Ticks_ISR = xTaskGetTickCount();
    UARTprintf("\n\rEntering timer interrupt");
    xSemaphoreGive(xSemaphore1);
}
#endif

#ifdef Q3
void Timer1_ISR_Handler( TimerHandle_t xTimer1 )
{
    Ticks_ISR = xTaskGetTickCount();
    //UARTprintf("\n\rEntering timer1 interrupt");
    xSemaphoreGive(xSemaphore1);
}

void Timer2_ISR_Handler( TimerHandle_t xTimer2 )
{
    Ticks_ISR = xTaskGetTickCount();
    //UARTprintf("\n\rEntering timer2 interrupt");
    xSemaphoreGive(xSemaphore2);
}
#endif
